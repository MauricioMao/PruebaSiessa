﻿class CambioBa
{
    static void Main(string[] args)
    {
        //Variables
        int resultDivCoc = 0; //valiable para el resultado de la division del cociente
        int resultDivRes = 0; //valiable para el resultado de la division del residuo
        int NumberXNew = 0; //variable para calcular el cociente
        int NumberX = 0; // variable digitado por el usuario en basse 10
        string ResRes = ""; // variable de residuo para el total

        //Numero digitado en base 10
        Console.WriteLine("Cual es el número en base 10:");
        NumberX = int.Parse(Console.ReadLine());
        //La base para convertir el numero
        Console.WriteLine("Cual es la base a convertir:");
        int BaseX = int.Parse(Console.ReadLine());

        NumberXNew = NumberX;

        do
        {
            resultDivCoc = (int)(NumberXNew / BaseX);//Operación de la division de numero digitado en base 10 con la base digitada por el usuario
            resultDivRes = (int)(NumberXNew % BaseX);//Operación para saber el residuo digitado en base 10 con la base digitada por el usuario
            ResRes = resultDivRes.ToString() + ResRes; //Asignacion para guardar el residuo
            Console.WriteLine("El cociente " + resultDivCoc + " residuo " + resultDivRes);//mostrar los resultados de la operacion
            NumberXNew = resultDivCoc;//Asginacion de nuevo valor para volver hacer el calculo
        } while (NumberXNew != 1); // mientras que el numero sea diferente a 1 para salir de la operacion

        Console.WriteLine("Por lo tanto " + NumberX + " en base 10 = " + NumberXNew + ResRes + " en base " + BaseX); //Muestra el resultado final

        Console.ReadLine();
    }
}