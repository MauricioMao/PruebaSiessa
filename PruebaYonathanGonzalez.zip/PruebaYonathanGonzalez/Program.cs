﻿using System.Buffers.Text;

class Program
{
    static void Main(string[] args)
    {
        //Arreglo para conocer los valores

        //En los corchetes{} escribir los valores, el valor 0 se cuenta como casilla vacia
        //Ejemplos:
        //{ 4, 0, 0 }, { 0, 0, 0 }, { 0, 0, 0 }
        //{ 4, 0, 0 }, { 1, 2, 0 }, { 0, 0, 0 }
        //{ 4, 0, 0 }, { 1, 2, 5 }, { 3, 1, 4 }
        int[,] multiDimensionalArray = { { 4, 0, 0 }, { 1, 2, 5 }, { 3, 1, 4 } };

        Console.WriteLine("Cual es la altura (Maxima sea 3):");
        int Altura = int.Parse(Console.ReadLine()); //Variable digita para el arbol asi sea 1 o 2 o 3

        int PesoValues = ArbolPeso(Altura, multiDimensionalArray); //Calculo de la función de Peso
        Decimal PesoPromedio = ArbolPesoPromedio(Altura, multiDimensionalArray);//Calculo de la función de Peso promedio
        int intArbolAltura = ArbolAltura(Altura, multiDimensionalArray);//Calculo de la función de Altura

        //Mostrar los resultados
        Console.WriteLine("Arbol: " + Altura);
        Console.WriteLine("Peso: " + PesoValues);
        Console.WriteLine("Peso Promedio: " + PesoPromedio);
        Console.WriteLine("Altura: " + intArbolAltura);

        Console.ReadLine();

    }

    //Función para calcular el peso del arbol
    static int ArbolPeso(int Altura, int[,] multiDimensionalArray)
    {
        int SumValues = 0;
        //Se recorre el arreglo para poder sumar los valores digitados
        for (int i = 0; i < Altura; i++)
        {
            for (int y = 0; y < Altura; y++)
            {
                SumValues = SumValues + multiDimensionalArray[i, y];
            }
        }

        return SumValues;
    }

    //Función para calcular la altura del arbol
    static int ArbolAltura(int Altura, int[,] multiDimensionalArray)
    {
        int AlturaLocal = 0;
        //Se recorre el arreglo para poder calcular la altura
        for (int i = 0; i < Altura; i++)
        {
            AlturaLocal++;
        }
        return AlturaLocal;
    }

    //Función para calcular lo valores que tiene el array, no se cuenta el 0
    static int ArbolValoresValidos(int Altura, int[,] multiDimensionalArray)
    {
        int NumTotal = 0;
        for (int i = 0; i < Altura; i++)
        {
            for (int y = 0; y < Altura; y++)
            {
                if (multiDimensionalArray[i, y] != 0)
                    NumTotal++;
            }
        }
        return NumTotal;
    }

    //Función para calcular el peso promedio del arreglo
    static Decimal ArbolPesoPromedio(int Altura, int[,] multiDimensionalArray)
    {
        int SumValues = ArbolPeso(Altura, multiDimensionalArray);
        int NumTotal = ArbolValoresValidos(Altura, multiDimensionalArray);

        Decimal resultLocal = (Decimal)SumValues / (Decimal)NumTotal;

        return resultLocal;
    }


}
